import React from "react";

const Contact = () => {
  return (
    <div className="h-screen w-full  flex items-center justify-center text-5xl">
      Ini halaman Kontak
    </div>
  );
};

export default Contact;