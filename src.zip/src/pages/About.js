import React from "react";

const About = () => {
  return (
    <div className="h-screen  flex items-center justify-center">
      <div className="text-center w-4/5 ">
        <h1 className="py-3">
          <a className="text-3xl text-blue-900" href="https://www.mabduh.com/">
            Hanif Amrin
          </a>
        </h1>
        <p>
          Hai! Assalamualaikum! saya sedang membuat website saya sendiri
          Saya menyukai bidang Teknologi, Politik Pemerintahan (Non Praktis), Agama Islam (Akidah, Fikih, Akhlak), serta Otomotif (Motor, Mobil, Kereta Api, Pesawat)
        </p>
      </div>
    </div>
  );
};


const Profile = () => {
  return (
    <div className="w-full text-center mx-auto p-4">
      <div className="w-full flex items-center">
        <div>
          <h2 className="text-lg font-semibold">Nama</h2>
          <p className="text-gray-600">Hanif Amrin</p>
        </div>
      </div>
      <div className="mt-8">
        <h3 className="text-lg font-semibold">Tentang Saya</h3>
        <p className="text-gray-600 mt-2">
         awdawdawdawdawdawdawdawd
        </p>
      </div>
    </div>
  );
};


export default About;
