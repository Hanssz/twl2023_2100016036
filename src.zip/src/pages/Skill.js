import React from "react";

const Skill = () => {
  return (
    <div className="h-screen w-full  flex items-center justify-center text-5xl">
      Skill atau keahlian yang saya miliki
    </div>
  );
};

export default Skill;
