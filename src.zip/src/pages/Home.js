import { useEffect, useState } from 'react';
// import { Link } from 'react-router-dom';

const Home = () => {
  return (
    <div className="h-screen flex items-center justify-center pt-60">
      <ProductList/>
    </div>
  );
};

function ProductList() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    fetch('https://fakestoreapi.com/products')
      .then(res => res.json())
      .then(json => setProducts(json))
      .catch(err => console.error(err));
  }, []);

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 pt-10">
      {products.map(product => (
        <div key={product.id} className="bg-white rounded-lg overflow-hidden shadow-md">
          <img src={product.image} alt={product.title} className="h-64 w-full object-cover" />
          <div className="p-4">
            <h2 className="text-lg font-medium">{product.title}</h2>
            <p className="text-gray-500">{product.description}</p>
            <p className="text-green-500 font-medium mt-2">${product.price}</p>
          </div>
        </div>
      ))}
    </div>
  );
}



export default Home;
